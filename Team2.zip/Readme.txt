Report Link :
https://docs.google.com/document/d/1d5ASGotslOgY5lAu6EDBGzajqQ2zwE__KWxaph3Ldts/edit#heading=h.3y3e0dqzldy0

Slides Link:
https://docs.google.com/presentation/d/1lFm9mHes7eEeAvDnsjjgpD8Ewjm_r7bt/edit#slide=id.g24508cfdc19_2_21


How to run:
from the master folder, run
python perform_inference.py

you will find preds.txt with the outputs printed separated by new lines, with no header.